## React Nodejs Socket.io

A simple React example using a Nodejs backend with Socket.io Connection. And TailwindCSS for the styles

![](./docs/screenshot.jpg)

## Tools

- Node.js
  - express
  - socket.io
- React
- [ngrok](https://ngrok.com/)
