import { ImagenPipePipe } from './imagen-pipe.pipe';

describe('ImagenPipePipe', () => {
  it('create an instance', () => {
    const pipe = new ImagenPipePipe();
    expect(pipe).toBeTruthy();
  });
});
