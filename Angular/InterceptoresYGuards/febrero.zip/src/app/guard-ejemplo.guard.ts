import { CanActivateFn } from '@angular/router';

export const guardEjemploGuard: CanActivateFn = (route, state) => {
  return true;
};
